import 'package:flutter/material.dart';

class AddRecipePage extends StatelessWidget {
  const AddRecipePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Recipe'),
        backgroundColor: Colors.orange, // Set app bar background color
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Recipe Name',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Enter recipe name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Chef Name',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Enter chef name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Preparation Time',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Enter preparation time',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Description',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            TextFormField(
              decoration: const InputDecoration(
                labelText: 'Enter description',
                border: OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
              maxLines: null,
            ),
           
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Add recipe logic here
              },
              child: const Text(
                'Add Recipe',
                style: TextStyle(fontSize: 18, color: Colors.black),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange, // Set button background color
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15), // Set button padding
              ),
            ),
          ],
        ),
      ),
    );
  }
}








// import 'package:flutter/material.dart';

// class AddRecipePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Add Recipe'),
//       ),
//       body: Padding(
//         padding: EdgeInsets.all(20),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             TextFormField(
//               decoration: InputDecoration(labelText: 'Recipe Name'),
//             ),
//             SizedBox(height: 20),
//             TextFormField(
//               decoration: InputDecoration(labelText: 'Chef Name'),
//             ),
//             SizedBox(height: 20),
//             TextFormField(
//               decoration: InputDecoration(labelText: 'Preparation Time'),
//             ),
//             SizedBox(height: 20),
//             TextFormField(
//               decoration: InputDecoration(labelText: 'Description'),
//               maxLines: null,
//             ),
//             SizedBox(height: 20),
//             TextFormField(
//               decoration: InputDecoration(labelText: 'Password'),
//               obscureText: true,
//             ),
//             SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () {
//                 // Add recipe logic here
//               },
//               child: Text('Add Recipe'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
