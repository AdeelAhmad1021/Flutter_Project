import 'package:flutter/material.dart';
import 'package:new_pro/login_page.dart';
import 'package:new_pro/setting.dart';
import 'package:new_pro/signup_page.dart';
import 'package:new_pro/profile.dart';
import 'package:new_pro/Category_Card.dart';
import 'package:new_pro/recipe_detail_screen.dart';
import 'package:new_pro/add_recipe.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => Homepage(),
        '/signup': (context) => SignupPage(),
        '/add_recipe': (context) => AddRecipePage(),
        '/profile': (context) => ProfilePage(),
        '/login': (context) => LoginPage(),
        '/settings': (context) =>
            SettingsPage(), // Added route for settings page
      },
    );
  }
}

class Homepage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange,
      bottomNavigationBar: SalomonBottomBar(
        items: [
          SalomonBottomBarItem(
            icon: Icon(Icons.home,color: Colors.black),
            title: Text('Home'),
            selectedColor: Colors.white,
          ),
          SalomonBottomBarItem(
            icon: Icon(Icons.add_circle,color:Colors.black),
            title: Text('Add Recipe'),
            selectedColor: Colors.white,
          ),
          SalomonBottomBarItem(
            icon: Icon(Icons.person,color:Colors.black),
            title: Text('Profile'),
            selectedColor: Colors.white,
          ),
        ],
        onTap: (int index) {
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/');
              break;
            case 1:
              Navigator.pushNamed(context, '/add_recipe');
              break;
            case 2:
              Navigator.pushNamed(context, '/profile');
              break;
          }
        },
      ),
      appBar: AppBar(
        title: Row(
          children: [
            Text(
              'Food Recipe',
              style: TextStyle(
                color: Colors.black,
              ),
            ),
            Expanded(
              child: SizedBox(), // Placeholder for search widget
            ),
          ],
        ),
        backgroundColor: Colors.orange,
        actions: [
          Padding(
            padding:
                EdgeInsets.only(right: 10.0), // Add spacing between buttons
            child: TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/signup');
              },
              child: Text(
                'Sign Up',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold, // Add bold font weight
                ),
              ),
              style: ButtonStyle(
                // Define button style
                padding: MaterialStateProperty.all<EdgeInsets>(
                    EdgeInsets.symmetric(horizontal: 16.0)), // Add padding
                backgroundColor: MaterialStateProperty.resolveWith<Color>(
                    (Set<MaterialState> states) {
                  // Define background color
                  if (states.contains(MaterialState.pressed)) {
                    return Colors.orangeAccent
                        .withOpacity(0.5); // Change color when pressed
                  }
                  return Colors.white; // Default color
                }),
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/login');
            },
            child: Text(
              'Login',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold, // Add bold font weight
              ),
            ),
            style: ButtonStyle(
              // Define button style
              padding: MaterialStateProperty.all<EdgeInsets>(
                  EdgeInsets.symmetric(horizontal: 16.0)), // Add padding
              backgroundColor: MaterialStateProperty.resolveWith<Color>(
                  (Set<MaterialState> states) {
                // Define background color
                if (states.contains(MaterialState.pressed)) {
                  return Colors.orangeAccent
                      .withOpacity(0.5); // Change color when pressed
                }
                return Colors.black; // Default color
              }),
            ),
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: Colors.orange,
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: Colors.white,
              ),
              accountName: Text(
                'Recipe App',
                style: TextStyle(color: Colors.black),
              ),
              accountEmail: Text(
                'recipeapp@gmail.com',
                style: TextStyle(color: Colors.black),
              ),
            ),
            ListTile(
              leading: Icon(Icons.settings, color: Colors.white),
              title: Text('Settings', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pushNamed(
                    context, '/settings'); // Navigate to Settings page
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Categories',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              CategoryCard(
                name: 'Quick and Eassy',
                // imageUrl: 'assets/images/tikka.jpg',
                imageUrl: 'assets/images/tikka.jpg',
                onTap: () {
                  // Navigate to RecipeDetailScreen passing the selected recipe
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RecipePage()),
                  );
                },
              ),
              SizedBox(height: 20.0),
              CategoryCard(
                name: 'Italian',
                imageUrl: 'assets/images/burger.jpg',
                onTap: () {
                  // Navigate to RecipeDetailScreen passing the selected recipe
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RecipePage()),
                  );
                },
              ),
              SizedBox(height: 20.0),
              CategoryCard(
                name: 'Asian',
                imageUrl: 'assets/images/chiken.jpg',
                onTap: () {
                  // Navigate to RecipeDetailScreen passing the selected recipe
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RecipePage()),
                  );
                },
              ),
              SizedBox(height: 20.0),
              CategoryCard(
                name: 'Chinese',
                imageUrl: 'assets/images/biryani.jpg',
                onTap: () {
                  // Navigate to RecipeDetailScreen passing the selected recipe
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RecipePage()),
                  );
                },
              ),
              SizedBox(height: 20.0),
              CategoryCard(
                name: 'Baking',
                imageUrl: 'assets/images/egg.jpg',
                onTap: () {
                  // Navigate to RecipeDetailScreen passing the selected recipe
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RecipePage()),
                  );
                },
              ),
              SizedBox(height: 20.0),
              CategoryCard(
                name: 'Sea Food',
                imageUrl: 'assets/images/msale.jpg',
                onTap: () {
                  // Navigate to RecipeDetailScreen passing the selected recipe
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RecipePage()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
